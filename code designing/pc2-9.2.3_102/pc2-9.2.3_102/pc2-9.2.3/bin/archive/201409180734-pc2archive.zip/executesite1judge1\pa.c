#include <fcntl.h>
#include <stdio.h>
#include <math.h>
int main()
{
	int i,j,k,m,n;
	int book[100010];
	//close(0); open("p2.txt",O_RDONLY);
	//freopen("pa.in","r",stdin);
	while (1) {
        scanf("%d%d",&n,&m);
        if (m==0) break;
        for (i=0;i<m;i++) book[i]=0;
        for (i=1;;i++) {
            if (book[n]>0) break;
            book[n]=i;
            n=(n*10)%m;
		}
		printf("%d\n",i-book[n]);
	}
	//close(0);

}
