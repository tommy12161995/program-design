#include <stdio.h>
#include <stdlib.h>
int main(void)
{
    int i,n,n1,n2,temp,q1,q2,r1,r2;
    scanf("%d",&n);
    while(n>0)
    {
        scanf("%d %d %d %d",&q1,&r1,&q2,&r2);
        n1=q1-r1;
        n2=q2-r2;
        do
        {
            temp=n1%n2;
            if(temp!=0)
            {
                n1=n2;
                n2=temp;
            }
        }while(temp!=0);
        for(i=1;i<=n2;i++)
        {
            if(n2%i==0)
            {
                printf("%d",i);
                if(i!=n2) printf(" ");
            }
        }
        printf("\n");
        n--;
    }
    return 0;
}
