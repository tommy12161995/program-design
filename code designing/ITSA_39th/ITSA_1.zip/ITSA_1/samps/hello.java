
//
// File:    hello.java
// Purpose: prints hello world
// Author:  pc2@ecs.csus.edu or http://www.ecs.csus.edu/pc2
// Oct 13 1998
//
// $Id: hello.java 543 2007-05-03 18:32:47Z laned $
//

public class hello {
    public static void main(String[] args) 
    {
         System.out.println("Hello World.");
    }
}

// eof
